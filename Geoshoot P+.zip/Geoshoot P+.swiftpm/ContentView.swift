import SwiftUI
import Combine

@main
struct ArenaSurvivorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - Safe Codable Save Data Struct
struct GameSaveData: Codable, Equatable {
    var totalCoins: Int = 0
    var totalGems: Int = 0
    
    // Upgrades
    var fireRateLevel: Int = 0
    var damageLevel: Int = 0
    var speedLevel: Int = 0
    var healthLevel: Int = 0
    var shieldLevel: Int = 0
    var critLevel: Int = 0
    var magnetLevel: Int = 0
    var regenLevel: Int = 0
    var globalRangeLevel: Int = 0
    var bombSkillLevel: Int = 0
    
    // Skills
    var chainSkillLevel: Int = 0
    var frostSkillLevel: Int = 0
    var multishotSkillLevel: Int = 0
    
    // Boss Tracking
    var maxBossDefeatedLevel: Int = 0
    
    init() {}
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.totalCoins = (try? container.decode(Int.self, forKey: .totalCoins)) ?? 0
        self.totalGems = (try? container.decode(Int.self, forKey: .totalGems)) ?? 0
        
        self.fireRateLevel = (try? container.decode(Int.self, forKey: .fireRateLevel)) ?? 0
        self.damageLevel = (try? container.decode(Int.self, forKey: .damageLevel)) ?? 0
        self.speedLevel = (try? container.decode(Int.self, forKey: .speedLevel)) ?? 0
        self.healthLevel = (try? container.decode(Int.self, forKey: .healthLevel)) ?? 0
        self.shieldLevel = (try? container.decode(Int.self, forKey: .shieldLevel)) ?? 0
        self.critLevel = (try? container.decode(Int.self, forKey: .critLevel)) ?? 0
        self.magnetLevel = (try? container.decode(Int.self, forKey: .magnetLevel)) ?? 0
        self.regenLevel = (try? container.decode(Int.self, forKey: .regenLevel)) ?? 0
        self.globalRangeLevel = (try? container.decode(Int.self, forKey: .globalRangeLevel)) ?? 0
        self.bombSkillLevel = (try? container.decode(Int.self, forKey: .bombSkillLevel)) ?? 0
        
        self.chainSkillLevel = (try? container.decode(Int.self, forKey: .chainSkillLevel)) ?? 0
        self.frostSkillLevel = (try? container.decode(Int.self, forKey: .frostSkillLevel)) ?? 0
        self.multishotSkillLevel = (try? container.decode(Int.self, forKey: .multishotSkillLevel)) ?? 0
        
        self.maxBossDefeatedLevel = (try? container.decode(Int.self, forKey: .maxBossDefeatedLevel)) ?? 0
    }
}

// MARK: - Save System
struct SaveSystem {
    private static var fileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("arena_save_v1.json")
    }
    
    static func save(_ data: GameSaveData) {
        do {
            let encodedData = try JSONEncoder().encode(data)
            try encodedData.write(to: fileURL, options: [.atomicWrite, .completeFileProtection])
        } catch {
            print("Save error: \(error.localizedDescription)")
        }
    }
    
    static func load() -> GameSaveData {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            let newData = GameSaveData()
            save(newData)
            return newData
        }
        do {
            let rawData = try Data(contentsOf: fileURL)
            return try JSONDecoder().decode(GameSaveData.self, from: rawData)
        } catch {
            print("Decode fallback used to preserve existing save file.")
            return GameSaveData()
        }
    }
}

// MARK: - Entities
enum EnemyType {
    case standard, speedster, tank, rusher, sniper, splitTarget, boss, spinnerBoss, diamondBoss, pentagonBoss, triangleBoss, whiteCircleOrbiter, rectShooter, bombThrower
}

struct Enemy: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var hp: Int
    var maxHp: Int
    var speed: CGFloat
    var radius: CGFloat
    var color: Color = .orange
    var type: EnemyType = .standard
    var moveVector: CGPoint = .zero
    var coinValue: Int = 1
    var contactDamage: Int = 10
    
    var rotationAngle: Double = 0
    var stateTimer: Int = 0
    var isSpinDashing: Bool = false
    var orbitCount: Int = 1
}

struct Bullet: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var velocity: CGPoint
    var damage: Int
    var isEnemy: Bool = false
    var isCrit: Bool = false
    var isTracking: Bool = false
    var trackingSpeed: CGFloat = 4.0
    var willExplode: Bool = false
}

struct ItemDrop: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var isGem: Bool = false
}

struct Particle: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var vx: CGFloat
    var vy: CGFloat
    var life: Double
    var color: Color
}

struct LightningArc: Identifiable {
    let id = UUID()
    var start: CGPoint
    var end: CGPoint
    var life: Double = 0.15
}

struct ExplosionRing: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var radius: CGFloat
    var maxRadius: CGFloat
    var color: Color
    var life: Double = 0.3
}

// MARK: - Main Game View
struct ContentView: View {
    @State private var saveData: GameSaveData = SaveSystem.load()
    @State private var startLevelChoice: Int = 1
    
    @State private var playerPos: CGPoint = .zero
    @State private var playerHp: Int = 100
    @State private var maxHp: Int = 100
    @State private var playerShield: Int = 0
    @State private var maxShield: Int = 0
    @State private var moveAngle: Double = 0
    @State private var isMoving: Bool = false
    @State private var gameSpeedMultiplier: Double = 1.0
    
    @State private var coinsCollected: Int = 0
    @State private var gemsCollected: Int = 0
    @State private var currentLevel: Int = 1
    @State private var enemiesKilled: Int = 0
    @State private var gameOver: Bool = false
    @State private var gameStarted: Bool = false
    
    @State private var enemies: [Enemy] = []
    @State private var bullets: [Bullet] = []
    @State private var drops: [ItemDrop] = []
    @State private var particles: [Particle] = []
    @State private var lightningArcs: [LightningArc] = []
    @State private var explosionRings: [ExplosionRing] = []
    
    @State private var spawnTimer: Int = 0
    @State private var shootTimer: Int = 0
    @State private var bossShootTimer: Int = 0
    @State private var bombTimer: Int = 0
    
    let timer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(red: 0.05, green: 0.05, blue: 0.1).ignoresSafeArea()
                
                if gameStarted && !gameOver {
                    ArenaCanvasView(
                        drops: drops,
                        explosionRings: explosionRings,
                        lightningArcs: lightningArcs,
                        bullets: bullets,
                        enemies: enemies,
                        particles: particles
                    )
                    PlayerView(
                        playerPos: playerPos,
                        playerShield: playerShield,
                        maxShield: maxShield,
                        moveAngle: moveAngle,
                        saveData: saveData
                    )
                    HUDView(
                        currentLevel: currentLevel,
                        totalCoins: saveData.totalCoins,
                        totalGems: saveData.totalGems,
                        playerHp: playerHp,
                        maxHp: maxHp,
                        playerShield: playerShield,
                        maxShield: maxShield,
                        gameSpeedMultiplier: $gameSpeedMultiplier,
                        onSelfDestruct: triggerSelfDestruct
                    )
                } else if gameOver {
                    UpgradeMenuView(
                        saveData: $saveData,
                        startLevelChoice: $startLevelChoice,
                        coinsCollected: coinsCollected,
                        gemsCollected: gemsCollected,
                        screenSize: geo.size,
                        onStartGame: { startNewGame(screenSize: geo.size) }
                    )
                } else {
                    StartMenuView(
                        saveData: saveData,
                        screenSize: geo.size,
                        onStartGame: { startNewGame(screenSize: geo.size) }
                    )
                }
            }
            .onChange(of: saveData) { _, newValue in
                SaveSystem.save(newValue)
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if gameStarted && !gameOver {
                            let dx = value.location.x - playerPos.x
                            let dy = value.location.y - playerPos.y
                            if (dx * dx + dy * dy) > 25 {
                                moveAngle = atan2(Double(dy), Double(dx))
                                isMoving = true
                            }
                        }
                    }
                    .onEnded { _ in isMoving = false }
            )
            .onReceive(timer) { _ in
                guard gameStarted && !gameOver else { return }
                updateGame(screenSize: geo.size)
            }
        }
    }
    
    private func getLevelScalingMultiplier() -> Double {
        let tiers = (currentLevel - 1) / 10
        return 1.0 + (Double(tiers) * 0.25)
    }
    
    private func updateGame(screenSize: CGSize) {
        let ticks = Int(gameSpeedMultiplier)
        for _ in 0..<ticks {
            runSingleGameTick(screenSize: screenSize)
        }
    }
    
    private func runSingleGameTick(screenSize: CGSize) {
        let speed: Double = 3.5 + (Double(saveData.speedLevel) * 0.6)
        
        if isMoving {
            playerPos.x += CGFloat(cos(moveAngle) * speed)
            playerPos.y += CGFloat(sin(moveAngle) * speed)
            playerPos.x = max(20, min(screenSize.width - 20, playerPos.x))
            playerPos.y = max(20, min(screenSize.height - 20, playerPos.y))
        }
        
        if saveData.regenLevel > 0 && playerHp < maxHp {
            let hpPerTick = Double(saveData.regenLevel) / 60.0
            playerHp = min(maxHp, playerHp + Int(hpPerTick))
        }
        
        if saveData.bombSkillLevel > 0 {
            bombTimer += 1
            let intervalSeconds = max(1, 180 / saveData.bombSkillLevel)
            let intervalFrames = intervalSeconds * 60
            if bombTimer >= intervalFrames {
                bombTimer = 0
                let bombsToThrow = Int(180.0 / Double(saveData.bombSkillLevel))
                let bombDamage = (1 + saveData.damageLevel) * 2
                let rangeMultiplier = 1.0 + (Double(saveData.globalRangeLevel) * 0.2)
                let explosionRadius = 150.0 * rangeMultiplier
                
                for _ in 0..<max(1, bombsToThrow) {
                    let randomOffset = CGPoint(x: CGFloat.random(in: -100...100), y: CGFloat.random(in: -100...100))
                    let targetBombPos = CGPoint(x: playerPos.x + randomOffset.x, y: playerPos.y + randomOffset.y)
                    
                    spawnParticles(at: targetBombPos, color: .orange)
                    explosionRings.append(ExplosionRing(pos: targetBombPos, radius: 10, maxRadius: explosionRadius, color: .orange))
                    
                    for eIdx in 0..<enemies.count {
                        let dist = hypot(Double(enemies[eIdx].pos.x - targetBombPos.x), Double(enemies[eIdx].pos.y - targetBombPos.y))
                        if dist < explosionRadius {
                            enemies[eIdx].hp -= bombDamage
                            spawnParticles(at: enemies[eIdx].pos, color: .yellow)
                        }
                    }
                }
            }
        }
        
        shootTimer += 1
        let fireInterval: Int = max(6, 22 - (saveData.fireRateLevel * 3))
        if shootTimer >= fireInterval {
            shootTimer = 0
            let bSpeed: Double = 12.0
            let isCrit: Bool = Double.random(in: 0...1) < (Double(saveData.critLevel) * 0.08)
            let baseDamage: Int = 1 + saveData.damageLevel
            let damage: Int = isCrit ? (baseDamage * 3) : baseDamage
            
            let bulletCount: Int = saveData.multishotSkillLevel + 1
            if bulletCount > 1 {
                let totalArc: Double = Double.pi
                let angleStep: Double = totalArc / Double(bulletCount + 1)
                for i in 1...bulletCount {
                    let offset: Double = (angleStep * Double(i)) - (totalArc / 2.0)
                    let bulletAngle: Double = moveAngle + offset
                    bullets.append(Bullet(pos: playerPos, velocity: CGPoint(x: CGFloat(cos(bulletAngle) * bSpeed), y: CGFloat(sin(bulletAngle) * bSpeed)), damage: damage, isCrit: isCrit))
                }
            } else {
                bullets.append(Bullet(pos: playerPos, velocity: CGPoint(x: CGFloat(cos(moveAngle) * bSpeed), y: CGFloat(sin(moveAngle) * bSpeed)), damage: damage, isCrit: isCrit))
            }
        }
        
        for i in (0..<bullets.count).reversed() {
            if bullets[i].isTracking {
                let dx = playerPos.x - bullets[i].pos.x
                let dy = playerPos.y - bullets[i].pos.y
                let dist = hypot(Double(dx), Double(dy))
                if dist > 1.0 {
                    let tSpeed = bullets[i].trackingSpeed
                    bullets[i].velocity = CGPoint(x: (dx / dist) * tSpeed, y: (dy / dist) * tSpeed)
                }
            }
            
            bullets[i].pos.x += bullets[i].velocity.x
            bullets[i].pos.y += bullets[i].velocity.y
            
            if bullets[i].isEnemy && bullets[i].willExplode {
                let distToPlayer = hypot(Double(playerPos.x - bullets[i].pos.x), Double(playerPos.y - bullets[i].pos.y))
                if distToPlayer < 25 {
                    explosionRings.append(ExplosionRing(pos: bullets[i].pos, radius: 10, maxRadius: 80, color: .orange))
                    damagePlayer(amount: bullets[i].damage * 2)
                    spawnParticles(at: bullets[i].pos, color: .orange)
                    bullets.remove(at: i)
                    continue
                }
            }
            
            if bullets[i].pos.x < -100 || bullets[i].pos.x > screenSize.width + 100 || bullets[i].pos.y < -100 || bullets[i].pos.y > screenSize.height + 100 {
                bullets.remove(at: i)
            }
        }
        
        spawnTimer += 1
        let spawnRate = max(10, 45 - (currentLevel * 2))
        if spawnTimer >= spawnRate {
            spawnTimer = 0
            let spawnPt = randomEdgePosition(screenSize: screenSize)
            let targetPt = CGPoint(x: CGFloat.random(in: 50...(screenSize.width - 50)), y: CGFloat.random(in: 50...(screenSize.height - 50)))
            let dx = targetPt.x - spawnPt.x
            let dy = targetPt.y - spawnPt.y
            let dist = max(1.0, CGFloat(hypot(Double(dx), Double(dy))))
            let moveVec = CGPoint(x: dx / dist, y: dy / dist)
            
            let scaling = getLevelScalingMultiplier()
            
            if currentLevel >= 100 && currentLevel <= 200 {
                let specialRoll = Int.random(in: 0...4)
                switch specialRoll {
                case 0:
                    let hp = Int(Double(currentLevel * 8) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: 1.1, radius: 38, color: .cyan, type: .diamondBoss, coinValue: Int(Double(currentLevel * 20) * scaling), contactDamage: Int(Double(currentLevel * 5) * scaling)))
                case 1:
                    let hp = Int(Double(currentLevel * 8) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: 1.2, radius: 38, color: .orange, type: .pentagonBoss, coinValue: Int(Double(currentLevel * 22) * scaling), contactDamage: Int(Double(currentLevel * 5) * scaling)))
                case 2:
                    let hp = Int(Double(currentLevel * 8) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: 1.3, radius: 36, color: .purple, type: .triangleBoss, coinValue: Int(Double(currentLevel * 22) * scaling), contactDamage: Int(Double(currentLevel * 5) * scaling)))
                case 3:
                    let hp = Int(Double(currentLevel * 4) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: 1.4, radius: 26, color: .white, type: .whiteCircleOrbiter, coinValue: Int(Double(currentLevel * 10) * scaling), contactDamage: Int(Double(currentLevel * 4) * scaling), orbitCount: Int.random(in: 1...3)))
                default:
                    let hp = Int(Double(currentLevel * 5) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: 1.2, radius: 28, color: .orange, type: .rectShooter, coinValue: Int(Double(currentLevel * 12) * scaling), contactDamage: Int(Double(currentLevel * 4) * scaling)))
                }
            } else if currentLevel % 5 == 0 && !enemies.contains(where: { $0.type == .boss || $0.type == .spinnerBoss || $0.type == .diamondBoss || $0.type == .pentagonBoss || $0.type == .triangleBoss }) {
                let bossCycle = (currentLevel / 5) % 3
                if currentLevel == 15 {
                    let bossHp = Int(Double(currentLevel * 9) * scaling)
                    let bossDmg = Int(Double(currentLevel * 7) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: bossHp, maxHp: bossHp, speed: 1.3, radius: 36, color: .purple, type: .triangleBoss, coinValue: Int(Double(currentLevel * 22) * scaling), contactDamage: bossDmg))
                } else if bossCycle == 1 {
                    let bossHp = Int(Double(currentLevel * 8) * scaling)
                    let bossDmg = Int(Double(currentLevel * 6) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: bossHp, maxHp: bossHp, speed: 1.5, radius: 36, color: .purple, type: .spinnerBoss, coinValue: Int(Double(currentLevel * 15) * scaling), contactDamage: bossDmg))
                } else if bossCycle == 2 {
                    let bossHp = Int(Double(currentLevel * 9) * scaling)
                    let bossDmg = Int(Double(currentLevel * 7) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: bossHp, maxHp: bossHp, speed: 1.1, radius: 38, color: .cyan, type: .diamondBoss, coinValue: Int(Double(currentLevel * 20) * scaling), contactDamage: bossDmg))
                } else {
                    let bossHp = Int(Double(currentLevel * 6) * scaling)
                    let bossDmg = Int(Double(currentLevel * 5) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: bossHp, maxHp: bossHp, speed: 1.2, radius: 32, color: .purple, type: .boss, coinValue: Int(Double(currentLevel * 10) * scaling), contactDamage: bossDmg))
                }
            } else {
                let roll = Double.random(in: 0...1)
                if currentLevel >= 8 && roll < 0.15 {
                    let hp = Int(Double(2) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: max(1, hp), maxHp: max(1, hp), speed: 1.0, radius: 16, color: .red, type: .sniper, coinValue: max(1, Int(Double(4) * scaling)), contactDamage: Int(Double(8) * scaling)))
                } else if currentLevel >= 5 && roll < 0.35 {
                    let hp = Int(Double(4) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: max(1, hp), maxHp: max(1, hp), speed: 1.6, radius: 20, color: .blue, type: .splitTarget, moveVector: moveVec, coinValue: max(1, Int(Double(3) * scaling)), contactDamage: Int(Double(10) * scaling)))
                } else if currentLevel >= 3 && roll < 0.55 {
                    let tankHp = Int(Double(6 + (currentLevel / 2)) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: max(1, tankHp), maxHp: max(1, tankHp), speed: 0.9, radius: 24, color: .green, type: .tank, moveVector: moveVec, coinValue: max(1, Int(Double(5) * scaling)), contactDamage: Int(Double(15) * scaling)))
                } else if roll < 0.75 {
                    let hp = Int(Double(1) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: max(1, hp), maxHp: max(1, hp), speed: 4.2, radius: 12, color: .yellow, type: .speedster, moveVector: moveVec, coinValue: max(1, Int(Double(2) * scaling)), contactDamage: Int(Double(6) * scaling)))
                } else {
                    let hp = Int(Double(1) * scaling)
                    enemies.append(Enemy(pos: spawnPt, hp: max(1, hp), maxHp: max(1, hp), speed: CGFloat.random(in: 2.0...3.0), radius: 14, color: .orange, type: .standard, moveVector: moveVec, coinValue: max(1, Int(Double(1) * scaling)), contactDamage: Int(Double(10) * scaling)))
                }
            }
        }
        
        let baseAuraRadius = CGFloat(40 + saveData.frostSkillLevel * 15)
        let rangeMultiplier = 1.0 + (Double(saveData.globalRangeLevel) * 0.2)
        let auraRadius = baseAuraRadius * rangeMultiplier
        
        for i in (0..<enemies.count).reversed() {
            var currentSpeed = enemies[i].speed
            let dx = playerPos.x - enemies[i].pos.x
            let dy = playerPos.y - enemies[i].pos.y
            let distToPlayer = CGFloat(hypot(Double(dx), Double(dy)))
            
            if saveData.frostSkillLevel > 0 && distToPlayer < auraRadius {
                let slowFactor = max(0.1, 1.0 - (Double(saveData.frostSkillLevel) * 0.15))
                currentSpeed *= slowFactor
            }
            
            if enemies[i].type == .spinnerBoss {
                enemies[i].rotationAngle += 0.12 * Double(gameSpeedMultiplier)
                enemies[i].stateTimer += 1
                
                if enemies[i].stateTimer > 180 {
                    enemies[i].isSpinDashing.toggle()
                    enemies[i].stateTimer = 0
                }
                
                if enemies[i].isSpinDashing {
                    currentSpeed *= 2.8
                    enemies[i].rotationAngle += 0.25
                }
                
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .diamondBoss {
                enemies[i].stateTimer += 1
                if enemies[i].stateTimer >= 150 {
                    enemies[i].stateTimer = 0
                    for _ in 0..<3 {
                        let offsetPos = CGPoint(
                            x: enemies[i].pos.x + CGFloat.random(in: -35...35),
                            y: enemies[i].pos.y + CGFloat.random(in: -35...35)
                        )
                        drops.append(ItemDrop(pos: offsetPos, isGem: true))
                    }
                    spawnParticles(at: enemies[i].pos, color: .pink)
                }
                
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .pentagonBoss {
                enemies[i].stateTimer += 1
                if enemies[i].stateTimer >= 160 {
                    enemies[i].stateTimer = 0
                    for k in 0..<10 {
                        let spreadOffset = Double(k - 5) * 0.12
                        let shootAngle = atan2(Double(dy), Double(dx)) + spreadOffset
                        bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(shootAngle) * 4.0), y: CGFloat(sin(shootAngle) * 4.0)), damage: Int(Double(currentLevel * 3) * getLevelScalingMultiplier()), isEnemy: true, isTracking: true, trackingSpeed: 3.5, willExplode: true))
                    }
                    spawnParticles(at: enemies[i].pos, color: .orange)
                }
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .triangleBoss {
                enemies[i].stateTimer += 1
                if enemies[i].stateTimer >= 180 {
                    enemies[i].stateTimer = 0
                    let bAngle = atan2(Double(dy), Double(dx))
                    bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(bAngle) * 6.0), y: CGFloat(sin(bAngle) * 6.0)), damage: Int(Double(currentLevel * 4) * getLevelScalingMultiplier()), isEnemy: true))
                    
                    for _ in 0..<3 {
                        let offset = CGPoint(x: CGFloat.random(in: -80...80), y: CGFloat.random(in: -80...80))
                        let bombTarget = CGPoint(x: playerPos.x + offset.x, y: playerPos.y + offset.y)
                        spawnParticles(at: bombTarget, color: .purple)
                        explosionRings.append(ExplosionRing(pos: bombTarget, radius: 10, maxRadius: 110, color: .purple))
                        if hypot(Double(playerPos.x - bombTarget.x), Double(playerPos.y - bombTarget.y)) < 110 {
                            damagePlayer(amount: Int(Double(currentLevel * 3) * getLevelScalingMultiplier()))
                        }
                    }
                    spawnParticles(at: enemies[i].pos, color: .pink)
                }
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .whiteCircleOrbiter {
                enemies[i].rotationAngle += 0.08 * Double(gameSpeedMultiplier)
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .rectShooter {
                enemies[i].stateTimer += 1
                if enemies[i].stateTimer >= 180 {
                    enemies[i].stateTimer = 0
                    for k in 0..<4 {
                        let spreadOffset = Double(k - 2) * 0.2
                        let shootAngle = atan2(Double(dy), Double(dx)) + spreadOffset
                        bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(shootAngle) * 3.5), y: CGFloat(sin(shootAngle) * 3.5)), damage: Int(Double(currentLevel * 2) * getLevelScalingMultiplier()), isEnemy: true, isTracking: true, trackingSpeed: 3.8))
                    }
                    spawnParticles(at: enemies[i].pos, color: .orange)
                }
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .bombThrower {
                enemies[i].stateTimer += 1
                if enemies[i].stateTimer >= 200 {
                    enemies[i].stateTimer = 0
                    let targetBombPos = playerPos
                    spawnParticles(at: targetBombPos, color: .red)
                    explosionRings.append(ExplosionRing(pos: targetBombPos, radius: 10, maxRadius: 100, color: .red))
                    if distToPlayer < 100 {
                        damagePlayer(amount: Int(Double(currentLevel * 4) * getLevelScalingMultiplier()))
                    }
                }
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .speedster || enemies[i].type == .tank || enemies[i].type == .boss {
                if distToPlayer > 0 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else if enemies[i].type == .sniper {
                if distToPlayer < 180 {
                    enemies[i].pos.x -= (dx / distToPlayer) * (currentSpeed * 0.8)
                    enemies[i].pos.y -= (dy / distToPlayer) * (currentSpeed * 0.8)
                } else if distToPlayer > 260 {
                    enemies[i].pos.x += (dx / distToPlayer) * currentSpeed
                    enemies[i].pos.y += (dy / distToPlayer) * currentSpeed
                }
            } else {
                enemies[i].pos.x += enemies[i].moveVector.x * currentSpeed
                enemies[i].pos.y += enemies[i].moveVector.y * currentSpeed
            }
            
            let isBossActive = (enemies[i].type == .boss || enemies[i].type == .spinnerBoss || enemies[i].type == .diamondBoss || enemies[i].type == .pentagonBoss || enemies[i].type == .triangleBoss)
            if !isBossActive && enemies[i].type != .whiteCircleOrbiter && enemies[i].type != .rectShooter && enemies[i].type != .bombThrower && enemies[i].type != .tank {
                if enemies[i].pos.x < -120 || enemies[i].pos.x > screenSize.width + 120 ||
                    enemies[i].pos.y < -120 || enemies[i].pos.y > screenSize.height + 120 {
                    enemies.remove(at: i)
                    continue
                }
            }
            
            if distToPlayer < (enemies[i].radius + 14) {
                damagePlayer(amount: enemies[i].contactDamage)
                spawnParticles(at: playerPos, color: .red)
                if !isBossActive { enemies.remove(at: i) }
                continue
            }
            
            if enemies[i].type == .boss {
                bossShootTimer += 1
                if bossShootTimer % 50 == 0 {
                    let bAngle = atan2(Double(dy), Double(dx))
                    let bossBulletDmg = Int(Double(currentLevel * 4) * getLevelScalingMultiplier())
                    bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(bAngle) * 6.5), y: CGFloat(sin(bAngle) * 6.5)), damage: bossBulletDmg, isEnemy: true))
                }
            } else if enemies[i].type == .spinnerBoss {
                bossShootTimer += 1
                if bossShootTimer % 40 == 0 && !enemies[i].isSpinDashing {
                    for k in 0..<4 {
                        let offsetAngle = Double(k) * (Double.pi / 2) + enemies[i].rotationAngle
                        bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(offsetAngle) * 5.5), y: CGFloat(sin(offsetAngle) * 5.5)), damage: Int(Double(currentLevel * 3) * getLevelScalingMultiplier()), isEnemy: true))
                    }
                }
            } else if enemies[i].type == .diamondBoss {
                bossShootTimer += 1
                if bossShootTimer % 60 == 0 {
                    for k in 0..<4 {
                        let shootAngle = Double(k) * (Double.pi / 2) + (Double(enemies[i].stateTimer) * 0.01)
                        bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(shootAngle) * 6.0), y: CGFloat(sin(shootAngle) * 6.0)), damage: Int(Double(currentLevel * 4) * getLevelScalingMultiplier()), isEnemy: true))
                    }
                }
            } else if enemies[i].type == .sniper {
                if Int.random(in: 0...120) == 0 {
                    let bAngle = atan2(Double(dy), Double(dx))
                    bullets.append(Bullet(pos: enemies[i].pos, velocity: CGPoint(x: CGFloat(cos(bAngle) * 8.5), y: CGFloat(sin(bAngle) * 8.5)), damage: Int(Double(15) * getLevelScalingMultiplier()), isEnemy: true))
                }
            }
        }
        
        for bIdx in (0..<bullets.count).reversed() {
            let b = bullets[bIdx]
            if b.isEnemy {
                if hypot(Double(playerPos.x - b.pos.x), Double(playerPos.y - b.pos.y)) < 18 {
                    damagePlayer(amount: b.damage)
                    spawnParticles(at: playerPos, color: .red)
                    bullets.remove(at: bIdx)
                }
                continue
            }
            
            var bulletHit = false
            for eIdx in 0..<enemies.count {
                let dist = hypot(Double(enemies[eIdx].pos.x - b.pos.x), Double(enemies[eIdx].pos.y - b.pos.y))
                if dist < Double(enemies[eIdx].radius + 6) {
                    spawnParticles(at: b.pos, color: b.isCrit ? .yellow : enemies[eIdx].color)
                    enemies[eIdx].hp -= b.damage
                    bulletHit = true
                    
                    if saveData.chainSkillLevel > 0 {
                        var chainedTargets = 0
                        let maxChains = saveData.chainSkillLevel + 1
                        let hitPos = enemies[eIdx].pos
                        
                        for otherIdx in 0..<enemies.count {
                            if otherIdx != eIdx && chainedTargets < maxChains {
                                let chainDist = hypot(Double(enemies[otherIdx].pos.x - hitPos.x), Double(enemies[otherIdx].pos.y - hitPos.y))
                                if chainDist < 120 {
                                    enemies[otherIdx].hp -= saveData.chainSkillLevel * 2
                                    lightningArcs.append(LightningArc(start: hitPos, end: enemies[otherIdx].pos))
                                    spawnParticles(at: enemies[otherIdx].pos, color: .cyan)
                                    chainedTargets += 1
                                }
                            }
                        }
                    }
                    break
                }
            }
            if bulletHit { bullets.remove(at: bIdx) }
        }
        
        for i in (0..<lightningArcs.count).reversed() {
            lightningArcs[i].life -= 1.0 / 60.0
            if lightningArcs[i].life <= 0 { lightningArcs.remove(at: i) }
        }
        
        for i in (0..<explosionRings.count).reversed() {
            explosionRings[i].radius += (explosionRings[i].maxRadius - explosionRings[i].radius) * 0.25
            explosionRings[i].life -= 1.0 / 60.0
            if explosionRings[i].life <= 0 { explosionRings.remove(at: i) }
        }
        
        for eIdx in (0..<enemies.count).reversed() {
            if enemies[eIdx].hp <= 0 {
                let e = enemies[eIdx]
                let isBossType = (e.type == .boss || e.type == .spinnerBoss || e.type == .diamondBoss || e.type == .pentagonBoss || e.type == .triangleBoss)
                if isBossType {
                    let alreadyBeaten = currentLevel <= saveData.maxBossDefeatedLevel
                    if alreadyBeaten {
                        let coinCount = Int(Double(currentLevel * 10) * getLevelScalingMultiplier())
                        for _ in 0..<coinCount {
                            drops.append(ItemDrop(pos: CGPoint(x: e.pos.x + CGFloat.random(in: -30...30), y: e.pos.y + CGFloat.random(in: -30...30)), isGem: false))
                        }
                    } else {
                        drops.append(ItemDrop(pos: e.pos, isGem: true))
                        saveData.maxBossDefeatedLevel = currentLevel
                    }
                    currentLevel += 1
                } else {
                    if e.type == .splitTarget {
                        for _ in 0..<2 {
                            let offsetPt = CGPoint(x: e.pos.x + CGFloat.random(in: -15...15), y: e.pos.y + CGFloat.random(in: -15...15))
                            let targetPt = CGPoint(x: CGFloat.random(in: 50...(screenSize.width - 50)), y: CGFloat.random(in: 50...(screenSize.height - 50)))
                            let dx = targetPt.x - offsetPt.x
                            let dy = targetPt.y - offsetPt.y
                            let dist = max(1.0, CGFloat(hypot(Double(dx), Double(dy))))
                            let moveVec = CGPoint(x: dx / dist, y: dy / dist)
                            enemies.append(Enemy(pos: offsetPt, hp: 1, maxHp: 1, speed: 2.8, radius: 12, color: .cyan, type: .standard, moveVector: moveVec, coinValue: 1, contactDamage: 5))
                        }
                    }
                    
                    for _ in 0..<e.coinValue {
                        drops.append(ItemDrop(pos: CGPoint(x: e.pos.x + CGFloat.random(in: -10...10), y: e.pos.y + CGFloat.random(in: -10...10)), isGem: false))
                    }
                    enemiesKilled += 1
                    if enemiesKilled % 8 == 0 { currentLevel += 1 }
                }
                enemies.remove(at: eIdx)
            }
        }
        
        let magnetRadius = CGFloat(30 + saveData.magnetLevel * 25)
        for i in (0..<drops.count).reversed() {
            let dx = playerPos.x - drops[i].pos.x
            let dy = playerPos.y - drops[i].pos.y
            let dist = CGFloat(hypot(Double(dx), Double(dy)))
            
            if saveData.magnetLevel > 0 && dist < magnetRadius {
                drops[i].pos.x += (dx / dist) * 6.0
                drops[i].pos.y += (dy / dist) * 6.0
            }
            
            if dist < 20 {
                if drops[i].isGem { saveData.totalGems += 1; gemsCollected += 1 }
                else { saveData.totalCoins += 1; coinsCollected += 1 }
                drops.remove(at: i)
            }
        }
        
        for i in (0..<particles.count).reversed() {
            particles[i].pos.x += particles[i].vx
            particles[i].pos.y += particles[i].vy
            particles[i].life -= 0.05
            if particles[i].life <= 0 { particles.remove(at: i) }
        }
    }
    
    private func triggerSelfDestruct() {
        spawnParticles(at: playerPos, color: .orange)
        spawnParticles(at: playerPos, color: .red)
        playerHp = 0
        gameOver = true
    }
    
    private func damagePlayer(amount: Int) {
        var remaining = amount
        if playerShield > 0 {
            if playerShield >= remaining { playerShield -= remaining; remaining = 0 }
            else { remaining -= playerShield; playerShield = 0 }
        }
        playerHp -= remaining
        
        if playerHp <= 0 { gameOver = true }
    }
    
    private func randomEdgePosition(screenSize: CGSize) -> CGPoint {
        switch Int.random(in: 0...3) {
        case 0: return CGPoint(x: CGFloat.random(in: 0...screenSize.width), y: -20)
        case 1: return CGPoint(x: screenSize.width + 20, y: CGFloat.random(in: 0...screenSize.height))
        case 2: return CGPoint(x: CGFloat.random(in: 0...screenSize.width), y: screenSize.height + 20)
        default: return CGPoint(x: -20, y: CGFloat.random(in: 0...screenSize.height))
        }
    }
    
    private func spawnParticles(at pt: CGPoint, color: Color) {
        for _ in 0..<8 {
            let angle = Double.random(in: 0...(2 * Double.pi))
            particles.append(Particle(pos: pt, vx: CGFloat(cos(angle) * 4), vy: CGFloat(sin(angle) * 4), life: 1.0, color: color))
        }
    }
    
    private func startNewGame(screenSize: CGSize) {
        maxHp = 100 + (saveData.healthLevel * 25)
        playerHp = maxHp
        let shieldBaseSize = saveData.shieldLevel * 20
        let shieldRangeMultiplier = 1.0 + (Double(saveData.globalRangeLevel) * 0.2)
        maxShield = Int(Double(shieldBaseSize) * shieldRangeMultiplier)
        playerShield = maxShield
        
        playerPos = CGPoint(x: screenSize.width / 2, y: screenSize.height / 2)
        currentLevel = startLevelChoice
        enemiesKilled = 0
        coinsCollected = 0
        gemsCollected = 0
        
        enemies.removeAll()
        bullets.removeAll()
        drops.removeAll()
        particles.removeAll()
        lightningArcs.removeAll()
        explosionRings.removeAll()
        
        gameOver = false
        gameStarted = true
    }
}

// MARK: - Extracted Component Views

struct ArenaCanvasView: View {
    let drops: [ItemDrop]
    let explosionRings: [ExplosionRing]
    let lightningArcs: [LightningArc]
    let bullets: [Bullet]
    let enemies: [Enemy]
    let particles: [Particle]
    
    var body: some View {
        Canvas { context, _ in
            for d in drops {
                let rect = CGRect(x: d.pos.x - 7, y: d.pos.y - 7, width: 14, height: 14)
                context.fill(Path(ellipseIn: rect), with: .color(d.isGem ? .purple : .yellow))
                if d.isGem { context.stroke(Path(ellipseIn: rect), with: .color(.pink), lineWidth: 2) }
            }
            
            for ring in explosionRings {
                let currentR = ring.radius
                let rect = CGRect(x: ring.pos.x - currentR, y: ring.pos.y - currentR, width: currentR * 2, height: currentR * 2)
                var ctxCopy = context
                ctxCopy.opacity = ring.life / 0.3
                ctxCopy.stroke(Path(ellipseIn: rect), with: .color(ring.color), lineWidth: 3.5)
            }
            
            for arc in lightningArcs {
                var path = Path()
                path.move(to: arc.start)
                let midX = (arc.start.x + arc.end.x) / 2 + CGFloat.random(in: -15...15)
                let midY = (arc.start.y + arc.end.y) / 2 + CGFloat.random(in: -15...15)
                path.addLine(to: CGPoint(x: midX, y: midY))
                path.addLine(to: arc.end)
                context.stroke(path, with: .color(.cyan), lineWidth: 3)
                context.stroke(path, with: .color(.white), lineWidth: 1.5)
            }
            
            for b in bullets {
                let size: CGFloat = b.isCrit ? 12 : 8
                let rect = CGRect(x: b.pos.x - size/2, y: b.pos.y - size/2, width: size, height: size)
                let bulletColor: Color = b.isEnemy ? (b.willExplode ? .orange : .red) : (b.isCrit ? .yellow : .cyan)
                context.fill(Path(rect), with: .color(bulletColor))
            }
            
            for e in enemies {
                let rect = CGRect(x: e.pos.x - e.radius, y: e.pos.y - e.radius, width: e.radius * 2, height: e.radius * 2)
                switch e.type {
                case .speedster, .rusher:
                    let path = Path { p in
                        p.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius))
                        p.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y + e.radius))
                        p.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y + e.radius))
                        p.closeSubpath()
                    }
                    context.fill(path, with: .color(e.color))
                    context.stroke(path, with: .color(.white.opacity(0.8)), lineWidth: 1.5)
                case .tank, .splitTarget:
                    context.fill(Path(rect), with: .color(e.color))
                    context.stroke(Path(rect), with: .color(.white.opacity(0.8)), lineWidth: 2)
                case .sniper:
                    let path = Path { p in
                        p.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius))
                        p.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y))
                        p.addLine(to: CGPoint(x: e.pos.x, y: e.pos.y + e.radius))
                        p.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y))
                        p.closeSubpath()
                    }
                    context.fill(path, with: .color(e.color))
                    context.stroke(path, with: .color(.white.opacity(0.8)), lineWidth: 1.5)
                case .spinnerBoss:
                    var transform = CGAffineTransform(translationX: e.pos.x, y: e.pos.y)
                    transform = transform.rotated(by: e.rotationAngle)
                    transform = transform.translatedBy(x: -e.pos.x, y: -e.pos.y)
                    
                    context.drawLayer { ctx in
                        ctx.concatenate(transform)
                        let ovalRect = CGRect(x: e.pos.x - e.radius * 1.4, y: e.pos.y - e.radius * 0.7, width: e.radius * 2.8, height: e.radius * 1.4)
                        ctx.fill(Path(ellipseIn: ovalRect), with: .color(e.isSpinDashing ? .pink : e.color))
                        ctx.stroke(Path(ellipseIn: ovalRect), with: .color(.white), lineWidth: 3)
                    }
                case .diamondBoss:
                    let diamondPath = Path { p in
                        p.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius * 1.3))
                        p.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y))
                        p.addLine(to: CGPoint(x: e.pos.x, y: e.pos.y + e.radius * 1.3))
                        p.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y))
                        p.closeSubpath()
                    }
                    context.fill(diamondPath, with: .color(.cyan))
                    context.stroke(diamondPath, with: .color(.white), lineWidth: 3.5)
                case .pentagonBoss:
                    let pentagonPath = Path { p in
                        for i in 0..<5 {
                            let angle = Double(i) * (2.0 * Double.pi / 5.0) - Double.pi / 2.0
                            let pt = CGPoint(x: e.pos.x + CGFloat(cos(angle)) * e.radius * 1.3, y: e.pos.y + CGFloat(sin(angle)) * e.radius * 1.3)
                            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
                        }
                        p.closeSubpath()
                    }
                    context.fill(pentagonPath, with: .color(.orange))
                    context.stroke(pentagonPath, with: .color(.white), lineWidth: 3.5)
                case .triangleBoss:
                    let trianglePath = Path { p in
                        p.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius * 1.4))
                        p.addLine(to: CGPoint(x: e.pos.x + e.radius * 1.2, y: e.pos.y + e.radius))
                        p.addLine(to: CGPoint(x: e.pos.x - e.radius * 1.2, y: e.pos.y + e.radius))
                        p.closeSubpath()
                    }
                    context.fill(trianglePath, with: .color(.purple))
                    context.stroke(trianglePath, with: .color(.pink), lineWidth: 3.5)
                case .whiteCircleOrbiter:
                    let circleRect = CGRect(x: e.pos.x - e.radius, y: e.pos.y - e.radius, width: e.radius * 2, height: e.radius * 2)
                    context.fill(Path(ellipseIn: circleRect), with: .color(.white))
                    context.stroke(Path(ellipseIn: circleRect), with: .color(.cyan), lineWidth: 2)
                    
                    let ringRect = CGRect(x: e.pos.x - e.radius * 2.2, y: e.pos.y - e.radius * 2.2, width: e.radius * 4.4, height: e.radius * 4.4)
                    context.stroke(Path(ellipseIn: ringRect), with: .color(.white.opacity(0.4)), lineWidth: 1.5)
                    
                    for k in 0..<e.orbitCount {
                        let angle = e.rotationAngle + (Double(k) * (2.0 * Double.pi / Double(e.orbitCount)))
                        let orbitDist = e.radius * 2.2
                        let smallX = e.pos.x + CGFloat(cos(angle) * orbitDist)
                        let smallY = e.pos.y + CGFloat(sin(angle) * orbitDist)
                        let smallRect = CGRect(x: smallX - 5, y: smallY - 5, width: 10, height: 10)
                        context.fill(Path(ellipseIn: smallRect), with: .color(.white))
                        context.stroke(Path(ellipseIn: smallRect), with: .color(.cyan), lineWidth: 1)
                    }
                case .rectShooter:
                    let rectPath = CGRect(x: e.pos.x - e.radius * 1.2, y: e.pos.y - e.radius * 0.7, width: e.radius * 2.4, height: e.radius * 1.4)
                    context.fill(Path(rectPath), with: .color(.orange))
                    context.stroke(Path(rectPath), with: .color(.white), lineWidth: 2)
                case .bombThrower:
                    let trianglePath = Path { p in
                        p.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius * 1.2))
                        p.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y + e.radius))
                        p.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y + e.radius))
                        p.closeSubpath()
                    }
                    context.fill(trianglePath, with: .color(.red))
                    context.stroke(trianglePath, with: .color(.yellow), lineWidth: 2)
                default:
                    context.fill(Path(ellipseIn: rect), with: .color(e.color))
                }
                
                if e.maxHp > 1 {
                    let hpPct = max(0.0, min(1.0, CGFloat(e.hp) / CGFloat(e.maxHp)))
                    let isBossType = (e.type == .boss || e.type == .spinnerBoss || e.type == .diamondBoss || e.type == .pentagonBoss || e.type == .triangleBoss)
                    let barWidth: CGFloat = isBossType ? 60 : 28
                    let barBg = CGRect(x: e.pos.x - (barWidth/2), y: e.pos.y - e.radius - 8, width: barWidth, height: 4)
                    let barFg = CGRect(x: e.pos.x - (barWidth/2), y: e.pos.y - e.radius - 8, width: barWidth * hpPct, height: 4)
                    context.fill(Path(barBg), with: .color(.gray.opacity(0.5)))
                    context.fill(Path(barFg), with: .color(.red))
                }
            }
            
            for p in particles {
                let rect = CGRect(x: p.pos.x - 2, y: p.pos.y - 2, width: 4, height: 4)
                var ctxCopy = context
                ctxCopy.opacity = p.life
                ctxCopy.fill(Path(rect), with: .color(p.color))
            }
        }
        .ignoresSafeArea()
    }
}

struct PlayerView: View {
    let playerPos: CGPoint
    let playerShield: Int
    let maxShield: Int
    let moveAngle: Double
    let saveData: GameSaveData
    
    var body: some View {
        ZStack {
            if saveData.frostSkillLevel > 0 {
                let frostBaseRadius: CGFloat = 80 + CGFloat(saveData.frostSkillLevel * 15)
                let frostRangeMultiplier = 1.0 + (Double(saveData.globalRangeLevel) * 0.2)
                Circle()
                    .stroke(Color.cyan.opacity(0.3), lineWidth: 2)
                    .frame(width: frostBaseRadius * frostRangeMultiplier, height: frostBaseRadius * frostRangeMultiplier)
                    .position(playerPos)
            }
            
            ZStack {
                if playerShield > 0 {
                    let shieldBaseSize: CGFloat = 44
                    let shieldRangeMultiplier = 1.0 + (Double(saveData.globalRangeLevel) * 0.2)
                    Circle()
                        .stroke(Color.cyan, lineWidth: 3)
                        .frame(width: shieldBaseSize * shieldRangeMultiplier, height: shieldBaseSize * shieldRangeMultiplier)
                        .shadow(color: .cyan, radius: 8)
                }
                Image(systemName: "location.north.fill")
                    .resizable()
                    .foregroundColor(.green)
                    .frame(width: 28, height: 28)
                    .rotationEffect(.radians(moveAngle + Double.pi / 2))
                    .shadow(color: .green, radius: 10)
            }
            .position(playerPos)
        }
    }
}

struct HUDView: View {
    let currentLevel: Int
    let totalCoins: Int
    let totalGems: Int
    let playerHp: Int
    let maxHp: Int
    let playerShield: Int
    let maxShield: Int
    @Binding var gameSpeedMultiplier: Double
    let onSelfDestruct: () -> Void
    
    var body: some View {
        VStack {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("LVL \(currentLevel)").font(.title3).bold().monospaced().foregroundColor(.white)
                    HStack(spacing: 12) {
                        Text("🪙 \(totalCoins)").font(.caption).monospaced().foregroundColor(.yellow)
                        Text("💎 \(totalGems)").font(.caption).monospaced().foregroundColor(.pink)
                    }
                }
                
                Spacer()
                
                HStack(spacing: 6) {
                    Button(action: {
                        if gameSpeedMultiplier == 4.0 { gameSpeedMultiplier = 2.0 }
                        else if gameSpeedMultiplier == 2.0 { gameSpeedMultiplier = 1.0 }
                    }) {
                        Text("⏪")
                            .font(.caption2).bold().monospaced().foregroundColor(.black)
                            .padding(.horizontal, 6).padding(.vertical, 6)
                            .background(Color.yellow).cornerRadius(6)
                    }
                    
                    Button(action: {
                        if gameSpeedMultiplier == 1.0 { gameSpeedMultiplier = 2.0 }
                        else if gameSpeedMultiplier == 2.0 { gameSpeedMultiplier = 4.0 }
                        else { gameSpeedMultiplier = 1.0 }
                    }) {
                        Text("⚡ \(Int(gameSpeedMultiplier))X")
                            .font(.caption2).bold().monospaced().foregroundColor(.black)
                            .padding(.horizontal, 8).padding(.vertical, 6)
                            .background(Color.yellow).cornerRadius(6)
                    }
                    
                    Button(action: {
                        if gameSpeedMultiplier == 1.0 { gameSpeedMultiplier = 2.0 }
                        else if gameSpeedMultiplier == 2.0 { gameSpeedMultiplier = 4.0 }
                    }) {
                        Text("⏩")
                            .font(.caption2).bold().monospaced().foregroundColor(.black)
                            .padding(.horizontal, 6).padding(.vertical, 6)
                            .background(Color.yellow).cornerRadius(6)
                    }
                    
                    Button(action: onSelfDestruct) {
                        Text("💥 SELF DESTRUCT")
                            .font(.caption2).bold().monospaced().foregroundColor(.white)
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(Color.red.opacity(0.8)).cornerRadius(6)
                    }
                }
                
                VStack(alignment: .trailing, spacing: 4) {
                    HStack {
                        Text("HP").font(.caption2).monospaced().foregroundColor(.red)
                        ProgressView(value: Double(playerHp), total: Double(maxHp))
                            .tint(.red).frame(width: 80)
                    }
                    if maxShield > 0 {
                        HStack {
                            Text("SHD").font(.caption2).monospaced().foregroundColor(.cyan)
                            ProgressView(value: Double(playerShield), total: Double(maxShield))
                                .tint(.cyan).frame(width: 80)
                        }
                    }
                }
            }
            .padding(.horizontal).padding(.top, 40)
            Spacer()
        }
    }
}

struct UpgradeMenuView: View {
    @Binding var saveData: GameSaveData
    @Binding var startLevelChoice: Int
    let coinsCollected: Int
    let gemsCollected: Int
    let screenSize: CGSize
    let onStartGame: () -> Void
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text("RUN OVER").font(.system(size: 36, weight: .bold)).monospaced().foregroundColor(.red)
                
                HStack(spacing: 20) {
                    Text("🪙 +\(coinsCollected) Coins").foregroundColor(.yellow)
                    Text("💎 +\(gemsCollected) Gems").foregroundColor(.pink)
                }.font(.title3).bold().monospaced()
                
                if saveData.maxBossDefeatedLevel >= 5 {
                    HStack {
                        Text("Start Level:").font(.caption).monospaced().foregroundColor(.white)
                        Picker("Start Level", selection: $startLevelChoice) {
                            Text("Lvl 1").tag(1)
                            ForEach(stride(from: 5, through: saveData.maxBossDefeatedLevel + 1, by: 5).map { $0 }, id: \.self) { lvl in
                                Text("Lvl \(lvl) ⚡").tag(lvl)
                            }
                        }.pickerStyle(.menu).tint(.cyan)
                    }.padding(8).background(Color.cyan.opacity(0.15)).cornerRadius(10)
                }
                
                Text("STAT UPGRADES").font(.headline).bold().monospaced().foregroundColor(.yellow)
                
                VStack(spacing: 6) {
                    upgradeRow(title: "💥 Bullet Damage", level: saveData.damageLevel, currency: "🪙", cost: (saveData.damageLevel + 1) * 0, canAfford: saveData.totalCoins >= (saveData.damageLevel + 1) * 0) {
                        buyUpgrade(cost: (saveData.damageLevel + 1) * 0) { saveData.damageLevel += 100 }
                    }
                    upgradeRow(title: "⚡ Fire Rate", level: saveData.fireRateLevel, currency: "🪙", cost: (saveData.fireRateLevel + 1) * 30, canAfford: saveData.totalCoins >= (saveData.fireRateLevel + 1) * 30) {
                        buyUpgrade(cost: (saveData.fireRateLevel + 1) * 30) { saveData.fireRateLevel += 100 }
                    }
                    upgradeRow(title: "🎯 Crit Chance", level: saveData.critLevel, currency: "🪙", cost: (saveData.critLevel + 1) * 25, canAfford: saveData.totalCoins >= (saveData.critLevel + 1) * 25) {
                        buyUpgrade(cost: (saveData.critLevel + 1) * 25) { saveData.critLevel += 1 }
                    }
                    upgradeRow(title: "🧲 Coin Magnet", level: saveData.magnetLevel, currency: "🪙", cost: (saveData.magnetLevel + 1) * 20, canAfford: saveData.totalCoins >= (saveData.magnetLevel + 1) * 20) {
                        buyUpgrade(cost: (saveData.magnetLevel + 1) * 20) { saveData.magnetLevel += 1 }
                    }
                    upgradeRow(title: "👟 Speed", level: saveData.speedLevel, currency: "🪙", cost: (saveData.speedLevel + 1) * 15, canAfford: saveData.totalCoins >= (saveData.speedLevel + 1) * 15) {
                        buyUpgrade(cost: (saveData.speedLevel + 1) * 15) { saveData.speedLevel += 1 }
                    }
                    upgradeRow(title: "❤️ Max HP", level: saveData.healthLevel, currency: "🪙", cost: (saveData.healthLevel + 1) * 0, canAfford: saveData.totalCoins >= (saveData.healthLevel + 1) * 0) {
                        buyUpgrade(cost: (saveData.healthLevel + 1) * 0) { saveData.healthLevel += 100 }
                    }
                    upgradeRow(title: "🛡️ Shield", level: saveData.shieldLevel, currency: "🪙", cost: (saveData.shieldLevel + 1) * 0, canAfford: saveData.totalCoins >= (saveData.shieldLevel + 1) * 0) {
                        buyUpgrade(cost: (saveData.shieldLevel + 1) * 0) { saveData.shieldLevel += 1 }
                    }
                    upgradeRow(title: "💚 Regeneration", level: saveData.regenLevel, currency: "🪙", cost: (saveData.regenLevel + 1) * 0, canAfford: saveData.totalCoins >= (saveData.regenLevel + 1) * 0) {
                        buyUpgrade(cost: (saveData.regenLevel + 1) * 0) { saveData.regenLevel += 100 }
                    }
                    upgradeRow(title: "🌐 Global Range", level: saveData.globalRangeLevel, currency: "🪙", cost: (saveData.globalRangeLevel + 1) * 50, canAfford: saveData.totalCoins >= (saveData.globalRangeLevel + 1) * 50) {
                        buyUpgrade(cost: (saveData.globalRangeLevel + 1) * 50) { saveData.globalRangeLevel += 1 }
                    }
                    upgradeRow(title: "💣 Bomb Frequency", level: saveData.bombSkillLevel, currency: "🪙", cost: (saveData.bombSkillLevel + 1) * 0, canAfford: saveData.totalCoins >= (saveData.bombSkillLevel + 1) * 0) {
                        buyUpgrade(cost: (saveData.bombSkillLevel + 1) * 0) { saveData.bombSkillLevel += 100 }
                    }
                }.padding(.horizontal)
                
                Text("SKILL SHOP").font(.headline).bold().monospaced().foregroundColor(.pink)
                
                VStack(spacing: 6) {
                    upgradeRow(title: "🔱 MultiShot Spread", level: saveData.multishotSkillLevel, currency: "💎", cost: 1, canAfford: saveData.totalGems >= 1) {
                        buyGemUpgrade(cost: 1) { saveData.multishotSkillLevel += 1 }
                    }
                    upgradeRow(title: "⚡ Chain Lightning", level: saveData.chainSkillLevel, currency: "💎", cost: 1, canAfford: saveData.totalGems >= 1) {
                        buyGemUpgrade(cost: 1) { saveData.chainSkillLevel += 1 }
                    }
                    upgradeRow(title: "❄️ Frost Aura", level: saveData.frostSkillLevel, currency: "💎", cost: 1, canAfford: saveData.totalGems >= 1) {
                        buyGemUpgrade(cost: 1) { saveData.frostSkillLevel += 1 }
                    }
                }.padding(.horizontal)
                
                Button(action: onStartGame) {
                    Text("START RUN (LVL \(startLevelChoice))").font(.title3).bold().monospaced().foregroundColor(.black)
                        .padding(.horizontal, 28).padding(.vertical, 12).background(Color.green).cornerRadius(10)
                }
            }.padding(.vertical, 20)
        }
    }
    
    private func buyUpgrade(cost: Int, apply: () -> Void) {
        if saveData.totalCoins >= cost {
            saveData.totalCoins -= cost
            apply()
        }
    }
    
    private func buyGemUpgrade(cost: Int, apply: () -> Void) {
        if saveData.totalGems >= cost {
            saveData.totalGems -= cost
            apply()
        }
    }
    
    @ViewBuilder
    private func upgradeRow(title: String, level: Int, currency: String, cost: Int, canAfford: Bool, onBuy: @escaping () -> Void) -> some View {
        HStack {
            VStack(alignment: .leading) {
                Text(title).font(.body).bold().monospaced().foregroundColor(.white)
                Text("Lvl \(level)").font(.caption).monospaced().foregroundColor(.gray)
            }
            Spacer()
            Button(action: onBuy) {
                Text("\(cost) \(currency)")
                    .font(.caption).bold().monospaced()
                    .foregroundColor(canAfford ? .black : .white)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(canAfford ? Color.yellow : Color.gray.opacity(0.4))
                    .cornerRadius(6)
            }
        }.padding(6).background(Color.white.opacity(0.05)).cornerRadius(8)
    }
}

struct StartMenuView: View {
    let saveData: GameSaveData
    let screenSize: CGSize
    let onStartGame: () -> Void
    
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "location.north.circle.fill")
                .font(.system(size: 70))
                .foregroundColor(.green)
                .shadow(color: .green, radius: 15)
            
            Text("Geometry Shoot").font(.system(size: 32, weight: .bold)).monospaced().foregroundColor(.white)
            Text("🪙 \(saveData.totalCoins) Coins | 💎 \(saveData.totalGems) Gems").font(.caption).monospaced().foregroundColor(.gray)
            Button(action: onStartGame) {
                Text("ENTER ARENA").font(.title3).bold().monospaced().foregroundColor(.black)
                    .padding(.horizontal, 28).padding(.vertical, 12).background(Color.cyan).cornerRadius(10)
            }
        }
    }
}


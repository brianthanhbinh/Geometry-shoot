import SwiftUI
import Combine

@main
struct ArenaSurvivorApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct GameSaveData: Codable, Equatable {
    var totalCoins = 0
    var totalGems = 0
    var fireRateLevel = 0
    var damageLevel = 0
    var speedLevel = 0
    var healthLevel = 0
    var shieldLevel = 0
    var critLevel = 0
    var magnetLevel = 0
    var regenLevel = 0
    var globalRangeLevel = 0
    var bombSkillLevel = 0
    var chainSkillLevel = 0
    var frostSkillLevel = 0
    var multishotSkillLevel = 0
    var maxBossDefeatedLevel = 0
}

struct SaveSystem {
    private static var fileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("arena_save_v1.json")
    }
    static func save(_ data: GameSaveData) {
        try? JSONEncoder().encode(data).write(to: fileURL, options: [.atomicWrite, .completeFileProtection])
    }
    static func load() -> GameSaveData {
        guard let data = try? Data(contentsOf: fileURL), let saved = try? JSONDecoder().decode(GameSaveData.self, from: data) else {
            let new = GameSaveData()
            save(new)
            return new
        }
        return saved
    }
}

enum EnemyType {
    case standard, speedster, tank, rusher, sniper, splitTarget, boss, spinnerBoss, diamondBoss, pentagonBoss, triangleBoss, whiteCircleOrbiter, rectShooter, bombThrower
}

struct Enemy: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var hp: Int
    var maxHp: Int
    var speed: CGFloat
    var radius: CGFloat
    var color: Color = .orange
    var type: EnemyType = .standard
    var moveVector: CGPoint = .zero
    var coinValue = 1
    var contactDamage = 10
    var rotationAngle = 0.0
    var stateTimer = 0
    var isSpinDashing = false
    var orbitCount = 1
}

struct Bullet: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var velocity: CGPoint
    var damage: Int
    var isEnemy = false
    var isCrit = false
    var isTracking = false
    var trackingSpeed = 4.0
    var willExplode = false
}

struct ItemDrop: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var isGem = false
}

struct Particle: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var vx: CGFloat
    var vy: CGFloat
    var life: Double
    var color: Color
}

struct LightningArc: Identifiable {
    let id = UUID()
    var start: CGPoint
    var end: CGPoint
    var life = 0.15
}

struct ExplosionRing: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var radius: CGFloat
    var maxRadius: CGFloat
    var color: Color
    var life = 0.3
}

struct ContentView: View {
    @State private var saveData = SaveSystem.load()
    @State private var startLevelChoice = 1
    @State private var playerPos = CGPoint.zero
    @State private var playerHp = 100
    @State private var maxHp = 100
    @State private var playerShield = 0
    @State private var maxShield = 0
    @State private var moveAngle = 0.0
    @State private var isMoving = false
    @State private var gameSpeedMultiplier = 1.0
    @State private var coinsCollected = 0
    @State private var gemsCollected = 0
    @State private var currentLevel = 1
    @State private var enemiesKilled = 0
    @State private var gameOver = false
    @State private var gameStarted = false
    @State private var enemies: [Enemy] = []
    @State private var bullets: [Bullet] = []
    @State private var drops: [ItemDrop] = []
    @State private var particles: [Particle] = []
    @State private var lightningArcs: [LightningArc] = []
    @State private var explosionRings: [ExplosionRing] = []
    @State private var spawnTimer = 0
    @State private var shootTimer = 0
    @State private var bombTimer = 0
    
    let timer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(red: 0.05, green: 0.05, blue: 0.1).ignoresSafeArea()
                
                if gameStarted && !gameOver {
                    arenaLayer
                    playerLayer
                    hudLayer
                } else if gameOver {
                    upgradeMenuLayer(screenSize: geo.size)
                } else {
                    startMenuLayer(screenSize: geo.size)
                }
            }
            .onChange(of: saveData) { _, n in
                SaveSystem.save(n)
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        if gameStarted && !gameOver {
                            let dx = v.location.x - playerPos.x
                            let dy = v.location.y - playerPos.y
                            if (dx * dx + dy * dy) > 25 {
                                moveAngle = atan2(Double(dy), Double(dx))
                                isMoving = true
                            }
                        }
                    }
                    .onEnded { _ in isMoving = false }
            )
            .onReceive(timer) { _ in
                guard gameStarted && !gameOver else { return }
                for _ in 0..<Int(gameSpeedMultiplier) {
                    updateGame(screenSize: geo.size)
                }
            }
        }
    }
    
    @ViewBuilder
    private var arenaLayer: some View {
        Canvas { context, _ in
            renderDrops(context: &context)
            renderExplosionRings(context: &context)
            renderLightningArcs(context: &context)
            renderBullets(context: &context)
            renderEnemies(context: &context)
            renderParticles(context: &context)
        }.ignoresSafeArea()
    }
    
    private func renderDrops(context: inout GraphicsContext) {
        for d in drops {
            let rect = CGRect(x: d.pos.x - 7, y: d.pos.y - 7, width: 14, height: 14)
            context.fill(Path(ellipseIn: rect), with: .color(d.isGem ? .purple : .yellow))
            if d.isGem {
                context.stroke(Path(ellipseIn: rect), with: .color(.pink), lineWidth: 2)
            }
        }
    }
    
    private func renderExplosionRings(context: inout GraphicsContext) {
        for ring in explosionRings {
            let rect = CGRect(x: ring.pos.x - ring.radius, y: ring.pos.y - ring.radius, width: ring.radius * 2, height: ring.radius * 2)
            var c = context
            c.opacity = ring.life / 0.3
            c.stroke(Path(ellipseIn: rect), with: .color(ring.color), lineWidth: 3.5)
        }
    }
    
    private func renderLightningArcs(context: inout GraphicsContext) {
        for arc in lightningArcs {
            var path = Path()
            path.move(to: arc.start)
            let midX = (arc.start.x + arc.end.x) / 2 + CGFloat.random(in: -15...15)
            let midY = (arc.start.y + arc.end.y) / 2 + CGFloat.random(in: -15...15)
            path.addLine(to: CGPoint(x: midX, y: midY))
            path.addLine(to: arc.end)
            context.stroke(path, with: .color(.cyan), lineWidth: 3)
            context.stroke(path, with: .color(.white), lineWidth: 1.5)
        }
    }
    
    private func renderBullets(context: inout GraphicsContext) {
        for b in bullets {
            let size: CGFloat = b.isCrit ? 12 : 8
            let rect = CGRect(x: b.pos.x - size/2, y: b.pos.y - size/2, width: size, height: size)
            let bulletColor: Color = b.isEnemy ? (b.willExplode ? .orange : .red) : (b.isCrit ? .yellow : .cyan)
            context.fill(Path(rect), with: .color(bulletColor))
        }
    }
    
    private func renderEnemies(context: inout GraphicsContext) {
        for e in enemies {
            let rect = CGRect(x: e.pos.x - e.radius, y: e.pos.y - e.radius, width: e.radius * 2, height: e.radius * 2)
            switch e.type {
            case .speedster, .rusher:
                let p = Path { path in
                    path.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius))
                    path.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y + e.radius))
                    path.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y + e.radius))
                    path.closeSubpath()
                }
                context.fill(p, with: .color(e.color))
                context.stroke(p, with: .color(.white.opacity(0.8)), lineWidth: 1.5)
            case .tank, .splitTarget:
                context.fill(Path(rect), with: .color(e.color))
                context.stroke(Path(rect), with: .color(.white.opacity(0.8)), lineWidth: 2)
            case .sniper:
                let p = Path { path in
                    path.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius))
                    path.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y))
                    path.addLine(to: CGPoint(x: e.pos.x, y: e.pos.y + e.radius))
                    path.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y))
                    path.closeSubpath()
                }
                context.fill(p, with: .color(e.color))
                context.stroke(p, with: .color(.white.opacity(0.8)), lineWidth: 1.5)
            case .spinnerBoss:
                let t = CGAffineTransform(translationX: e.pos.x, y: e.pos.y).rotated(by: e.rotationAngle).translatedBy(x: -e.pos.x, y: -e.pos.y)
                context.drawLayer { ctx in
                    var mutableCtx = ctx
                    mutableCtx.concatenate(t)
                    let oval = CGRect(x: e.pos.x - e.radius * 1.4, y: e.pos.y - e.radius * 0.7, width: e.radius * 2.8, height: e.radius * 1.4)
                    let bossColor: Color = e.isSpinDashing ? .pink : e.color
                    mutableCtx.fill(Path(ellipseIn: oval), with: .color(bossColor))
                    mutableCtx.stroke(Path(ellipseIn: oval), with: .color(.white), lineWidth: 3)
                }
            case .diamondBoss:
                let p = Path { path in
                    path.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius * 1.3))
                    path.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y))
                    path.addLine(to: CGPoint(x: e.pos.x, y: e.pos.y + e.radius * 1.3))
                    path.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y))
                    path.closeSubpath()
                }
                context.fill(p, with: .color(.cyan))
                context.stroke(p, with: .color(.white), lineWidth: 3.5)
            case .pentagonBoss:
                let p = Path { path in
                    for idx in 0..<5 {
                        let angle = Double(idx) * 1.2566 - 1.5708
                        let pt = CGPoint(x: e.pos.x + CGFloat(cos(angle)) * e.radius * 1.3, y: e.pos.y + CGFloat(sin(angle)) * e.radius * 1.3)
                        if idx == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
                    }
                    path.closeSubpath()
                }
                context.fill(p, with: .color(.orange))
                context.stroke(p, with: .color(.white), lineWidth: 3.5)
            case .triangleBoss:
                let p = Path { path in
                    path.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius * 1.4))
                    path.addLine(to: CGPoint(x: e.pos.x + e.radius * 1.2, y: e.pos.y + e.radius))
                    path.addLine(to: CGPoint(x: e.pos.x - e.radius * 1.2, y: e.pos.y + e.radius))
                    path.closeSubpath()
                }
                context.fill(p, with: .color(.purple))
                context.stroke(p, with: .color(.pink), lineWidth: 3.5)
            case .whiteCircleOrbiter:
                context.fill(Path(ellipseIn: rect), with: .color(.white))
                context.stroke(Path(ellipseIn: rect), with: .color(.cyan), lineWidth: 2)
                let ring = CGRect(x: e.pos.x - e.radius * 2.2, y: e.pos.y - e.radius * 2.2, width: e.radius * 4.4, height: e.radius * 4.4)
                context.stroke(Path(ellipseIn: ring), with: .color(.white.opacity(0.4)), lineWidth: 1.5)
                for k in 0..<e.orbitCount {
                    let angle = e.rotationAngle + (Double(k) * 6.2831 / Double(e.orbitCount))
                    let smallX = e.pos.x + CGFloat(cos(angle) * e.radius * 2.2) - 5
                    let smallY = e.pos.y + CGFloat(sin(angle) * e.radius * 2.2) - 5
                    let small = CGRect(x: smallX, y: smallY, width: 10, height: 10)
                    context.fill(Path(ellipseIn: small), with: .color(.white))
                    context.stroke(Path(ellipseIn: small), with: .color(.cyan), lineWidth: 1)
                }
            case .rectShooter:
                let r = CGRect(x: e.pos.x - e.radius * 1.2, y: e.pos.y - e.radius * 0.7, width: e.radius * 2.4, height: e.radius * 1.4)
                context.fill(Path(r), with: .color(.orange))
                context.stroke(Path(r), with: .color(.white), lineWidth: 2)
            case .bombThrower:
                let p = Path { path in
                    path.move(to: CGPoint(x: e.pos.x, y: e.pos.y - e.radius * 1.2))
                    path.addLine(to: CGPoint(x: e.pos.x + e.radius, y: e.pos.y + e.radius))
                    path.addLine(to: CGPoint(x: e.pos.x - e.radius, y: e.pos.y + e.radius))
                    path.closeSubpath()
                }
                context.fill(p, with: .color(.red))
                context.stroke(p, with: .color(.yellow), lineWidth: 2)
            default:
                context.fill(Path(ellipseIn: rect), with: .color(e.color))
            }
            if e.maxHp > 1 {
                let isBossType = [.boss, .spinnerBoss, .diamondBoss, .pentagonBoss, .triangleBoss].contains(e.type)
                let barWidth: CGFloat = isBossType ? 60 : 28
                let hpRatio = max(0, min(1, CGFloat(e.hp) / CGFloat(e.maxHp)))
                let bgRect = CGRect(x: e.pos.x - barWidth/2, y: e.pos.y - e.radius - 8, width: barWidth, height: 4)
                let fgRect = CGRect(x: e.pos.x - barWidth/2, y: e.pos.y - e.radius - 8, width: barWidth * hpRatio, height: 4)
                context.fill(Path(bgRect), with: .color(.gray.opacity(0.5)))
                context.fill(Path(fgRect), with: .color(.red))
            }
        }
    }
    
    private func renderParticles(context: inout GraphicsContext) {
        for p in particles {
            var c = context
            c.opacity = p.life
            let rect = CGRect(x: p.pos.x - 2, y: p.pos.y - 2, width: 4, height: 4)
            c.fill(Path(rect), with: .color(p.color))
        }
    }
    
    @ViewBuilder
    private var playerLayer: some View {
        ZStack {
            if saveData.frostSkillLevel > 0 {
                frostAuraView
            }
            
            ZStack {
                if playerShield > 0 {
                    shieldView
                }
                
                Image(systemName: "location.north.fill")
                    .resizable()
                    .foregroundColor(.green)
                    .frame(width: 28, height: 28)
                    .rotationEffect(.radians(moveAngle + 1.5708))
                    .shadow(color: .green, radius: 10)
            }
            .position(playerPos)
        }
    }
    
    @ViewBuilder
    private var frostAuraView: some View {
        let baseRadius: CGFloat = 80 + CGFloat(saveData.frostSkillLevel * 15)
        let rangeMultiplier = 1.0 + Double(saveData.globalRangeLevel) * 0.2
        let r = baseRadius * rangeMultiplier
        
        Circle()
            .stroke(Color.cyan.opacity(0.3), lineWidth: 2)
            .frame(width: r, height: r)
            .position(playerPos)
    }
    
    @ViewBuilder
    private var shieldView: some View {
        let rangeMultiplier = 1.0 + Double(saveData.globalRangeLevel) * 0.2
        let r = 44 * rangeMultiplier
        
        Circle()
            .stroke(Color.cyan, lineWidth: 3)
            .frame(width: r, height: r)
            .shadow(color: .cyan, radius: 8)
    }
    
    @ViewBuilder
    private var hudLayer: some View {
        VStack {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("LVL \(currentLevel)").font(.title3).bold().monospaced().foregroundColor(.white)
                    HStack(spacing: 12) {
                        Text("🪙 \(saveData.totalCoins)").font(.caption).monospaced().foregroundColor(.yellow)
                        Text("💎 \(saveData.totalGems)").font(.caption).monospaced().foregroundColor(.pink)
                    }
                }
                Spacer()
                HStack(spacing: 6) {
                    Button(action: {
                        if gameSpeedMultiplier == 4.0 { gameSpeedMultiplier = 2.0 } else if gameSpeedMultiplier == 2.0 { gameSpeedMultiplier = 1.0 }
                    }) { speedBtnText("⏪", bg: .yellow) }
                    Button(action: {
                        gameSpeedMultiplier = gameSpeedMultiplier == 1.0 ? 2.0 : (gameSpeedMultiplier == 2.0 ? 4.0 : 1.0)
                    }) { speedBtnText("⚡ \(Int(gameSpeedMultiplier))X", bg: .yellow) }
                    Button(action: {
                        if gameSpeedMultiplier == 1.0 { gameSpeedMultiplier = 2.0 } else if gameSpeedMultiplier == 2.0 { gameSpeedMultiplier = 4.0 }
                    }) { speedBtnText("⏩", bg: .yellow) }
                    Button(action: triggerSelfDestruct) { speedBtnText("💥 SELF DESTRUCT", bg: Color.red.opacity(0.8), fg: .white) }
                }
                VStack(alignment: .trailing, spacing: 4) {
                    HStack {
                        Text("HP").font(.caption2).monospaced().foregroundColor(.red)
                        ProgressView(value: Double(playerHp), total: Double(maxHp)).tint(.red).frame(width: 80)
                    }
                    if maxShield > 0 {
                        HStack {
                            Text("SHD").font(.caption2).monospaced().foregroundColor(.cyan)
                            ProgressView(value: Double(playerShield), total: Double(maxShield)).tint(.cyan).frame(width: 80)
                        }
                    }
                }
            }.padding(.horizontal).padding(.top, 40)
            Spacer()
        }
    }
    
    private func speedBtnText(_ text: String, bg: Color, fg: Color = .black) -> some View {
        Text(text).font(.caption2).bold().monospaced().foregroundColor(fg).padding(.horizontal, 6).padding(.vertical, 6).background(bg).cornerRadius(6)
    }
    
    @ViewBuilder
    private func upgradeMenuLayer(screenSize: CGSize) -> some View {
        ScrollView {
            VStack(spacing: 16) {
                Text("RUN OVER").font(.system(size: 36, weight: .bold)).monospaced().foregroundColor(.red)
                HStack(spacing: 20) {
                    Text("🪙 +\(coinsCollected) Coins").foregroundColor(.yellow)
                    Text("💎 +\(gemsCollected) Gems").foregroundColor(.pink)
                }.font(.title3).bold().monospaced()
                
                if saveData.maxBossDefeatedLevel >= 5 {
                    HStack {
                        Text("Start Level:").font(.caption).monospaced().foregroundColor(.white)
                        Picker("Start Level", selection: $startLevelChoice) {
                            Text("Lvl 1").tag(1)
                            ForEach(stride(from: 5, through: saveData.maxBossDefeatedLevel + 1, by: 5).map { $0 }, id: \.self) { lvl in
                                Text("Lvl \(lvl) ⚡").tag(lvl)
                            }
                        }.pickerStyle(.menu).tint(.cyan)
                    }.padding(8).background(Color.cyan.opacity(0.15)).cornerRadius(10)
                }
                
                Text("STAT UPGRADES").font(.headline).bold().monospaced().foregroundColor(.yellow)
                VStack(spacing: 6) {
                    upgradeRow(title: "💥 Bullet Damage", level: saveData.damageLevel, cost: (saveData.damageLevel + 1) * 15, canAfford: saveData.totalCoins >= (saveData.damageLevel + 1) * 15) {
                        buy(&saveData.totalCoins, cost: (saveData.damageLevel + 1) * 15) { saveData.damageLevel += 1 }
                    }
                    upgradeRow(title: "⚡ Fire Rate", level: saveData.fireRateLevel, cost: (saveData.fireRateLevel + 1) * 20, canAfford: saveData.totalCoins >= (saveData.fireRateLevel + 1) * 20) {
                        buy(&saveData.totalCoins, cost: (saveData.fireRateLevel + 1) * 20) { saveData.fireRateLevel += 1 }
                    }
                    upgradeRow(title: "🎯 Crit Chance", level: saveData.critLevel, cost: (saveData.critLevel + 1) * 25, canAfford: saveData.totalCoins >= (saveData.critLevel + 1) * 25) {
                        buy(&saveData.totalCoins, cost: (saveData.critLevel + 1) * 25) { saveData.critLevel += 1 }
                    }
                    upgradeRow(title: "🧲 Coin Magnet", level: saveData.magnetLevel, cost: (saveData.magnetLevel + 1) * 20, canAfford: saveData.totalCoins >= (saveData.magnetLevel + 1) * 20) {
                        buy(&saveData.totalCoins, cost: (saveData.magnetLevel + 1) * 20) { saveData.magnetLevel += 1 }
                    }
                    upgradeRow(title: "👟 Speed", level: saveData.speedLevel, cost: (saveData.speedLevel + 1) * 10, canAfford: saveData.totalCoins >= (saveData.speedLevel + 1) * 10) {
                        buy(&saveData.totalCoins, cost: (saveData.speedLevel + 1) * 10) { saveData.speedLevel += 1 }
                    }
                    upgradeRow(title: "❤️ Max HP", level: saveData.healthLevel, cost: (saveData.healthLevel + 1) * 15, canAfford: saveData.totalCoins >= (saveData.healthLevel + 1) * 15) {
                        buy(&saveData.totalCoins, cost: (saveData.healthLevel + 1) * 15) { saveData.healthLevel += 1 }
                    }
                    upgradeRow(title: "🛡️ Shield", level: saveData.shieldLevel, cost: (saveData.shieldLevel + 1) * 25, canAfford: saveData.totalCoins >= (saveData.shieldLevel + 1) * 25) {
                        buy(&saveData.totalCoins, cost: (saveData.shieldLevel + 1) * 25) { saveData.shieldLevel += 1 }
                    }
                    upgradeRow(title: "💚 Regeneration", level: saveData.regenLevel, cost: (saveData.regenLevel + 1) * 30, canAfford: saveData.totalCoins >= (saveData.regenLevel + 1) * 30) {
                        buy(&saveData.totalCoins, cost: (saveData.regenLevel + 1) * 30) { saveData.regenLevel += 1 }
                    }
                    upgradeRow(title: "🌐 Global Range", level: saveData.globalRangeLevel, cost: (saveData.globalRangeLevel + 1) * 50, canAfford: saveData.totalCoins >= (saveData.globalRangeLevel + 1) * 50) {
                        buy(&saveData.totalCoins, cost: (saveData.globalRangeLevel + 1) * 50) { saveData.globalRangeLevel += 1 }
                    }
                    upgradeRow(title: "💣 Bomb Frequency", level: saveData.bombSkillLevel, cost: (saveData.bombSkillLevel + 1) * 40, canAfford: saveData.totalCoins >= (saveData.bombSkillLevel + 1) * 40) {
                        buy(&saveData.totalCoins, cost: (saveData.bombSkillLevel + 1) * 40) { saveData.bombSkillLevel += 1 }
                    }
                }.padding(.horizontal)
                
                Text("SKILL SHOP").font(.headline).bold().monospaced().foregroundColor(.pink)
                VStack(spacing: 6) {
                    gemUpgradeRow(title: "🔱 MultiShot Spread", level: saveData.multishotSkillLevel) {
                        buy(&saveData.totalGems, cost: 1) { saveData.multishotSkillLevel += 1 }
                    }
                    gemUpgradeRow(title: "⚡ Chain Lightning", level: saveData.chainSkillLevel) {
                        buy(&saveData.totalGems, cost: 1) { saveData.chainSkillLevel += 1 }
                    }
                    gemUpgradeRow(title: "❄️ Frost Aura", level: saveData.frostSkillLevel) {
                        buy(&saveData.totalGems, cost: 1) { saveData.frostSkillLevel += 1 }
                    }
                }.padding(.horizontal)
                
                Button(action: { startNewGame(screenSize: screenSize) }) {
                    Text("START RUN (LVL \(startLevelChoice))").font(.title3).bold().monospaced().foregroundColor(.black).padding(.horizontal, 28).padding(.vertical, 12).background(Color.green).cornerRadius(10)
                }
            }.padding(.vertical, 20)
        }
    }
    
    @ViewBuilder
    private func startMenuLayer(screenSize: CGSize) -> some View {
        VStack(spacing: 16) {
            Image(systemName: "location.north.circle.fill").font(.system(size: 70)).foregroundColor(.green).shadow(color: .green, radius: 15)
            Text("Geometry Shoot").font(.system(size: 32, weight: .bold)).monospaced().foregroundColor(.white)
            Text("🪙 \(saveData.totalCoins) Coins | 💎 \(saveData.totalGems) Gems").font(.caption).monospaced().foregroundColor(.gray)
            Button(action: { startNewGame(screenSize: screenSize) }) {
                Text("ENTER ARENA").font(.title3).bold().monospaced().foregroundColor(.black).padding(.horizontal, 28).padding(.vertical, 12).background(Color.cyan).cornerRadius(10)
            }
        }
    }
    
    private func getLevelScaling() -> Double {
        return 1.0 + Double((currentLevel - 1) / 10) * 0.25
    }
    
    private func updateGame(screenSize: CGSize) {
        let speed = 3.5 + Double(saveData.speedLevel) * 0.6
        if isMoving {
            playerPos.x = max(20, min(screenSize.width - 20, playerPos.x + CGFloat(cos(moveAngle) * speed)))
            playerPos.y = max(20, min(screenSize.height - 20, playerPos.y + CGFloat(sin(moveAngle) * speed)))
        }
        if saveData.regenLevel > 0 && playerHp < maxHp {
            playerHp = min(maxHp, playerHp + Int(Double(saveData.regenLevel) / 60.0))
        }
        
        if saveData.bombSkillLevel > 0 {
            bombTimer += 1
            let bombInterval = max(1, 180 / saveData.bombSkillLevel) * 60
            if bombTimer >= bombInterval {
                bombTimer = 0
                let dmg = (1 + saveData.damageLevel) * 2
                let rad = 150.0 * (1.0 + Double(saveData.globalRangeLevel) * 0.2)
                let pt = CGPoint(x: playerPos.x + CGFloat.random(in: -100...100), y: playerPos.y + CGFloat.random(in: -100...100))
                spawnParticles(at: pt, color: .orange)
                explosionRings.append(ExplosionRing(pos: pt, radius: 10, maxRadius: rad, color: .orange))
                for idx in 0..<enemies.count {
                    if hypot(Double(enemies[idx].pos.x - pt.x), Double(enemies[idx].pos.y - pt.y)) < rad {
                        enemies[idx].hp -= dmg
                        spawnParticles(at: enemies[idx].pos, color: .yellow)
                    }
                }
            }
        }
        
        shootTimer += 1
        let shootInterval = max(6, 22 - saveData.fireRateLevel * 2)
        if shootTimer >= shootInterval {
            shootTimer = 0
            let isCrit = Double.random(in: 0...1) < Double(saveData.critLevel) * 0.08
            let dmg = isCrit ? (1 + saveData.damageLevel) * 3 : 1 + saveData.damageLevel
            let count = saveData.multishotSkillLevel + 1
            if count > 1 {
                for idx in 1...count {
                    let angle = moveAngle + (3.1415 / Double(count + 1) * Double(idx) - 1.5708)
                    bullets.append(Bullet(pos: playerPos, velocity: CGPoint(x: CGFloat(cos(angle) * 12), y: CGFloat(sin(angle) * 12)), damage: dmg, isCrit: isCrit))
                }
            } else {
                bullets.append(Bullet(pos: playerPos, velocity: CGPoint(x: CGFloat(cos(moveAngle) * 12), y: CGFloat(sin(moveAngle) * 12)), damage: dmg, isCrit: isCrit))
            }
        }
        
        for idx in (0..<bullets.count).reversed() {
            if bullets[idx].isTracking {
                let dx = playerPos.x - bullets[idx].pos.x
                let dy = playerPos.y - bullets[idx].pos.y
                let d = hypot(Double(dx), Double(dy))
                if d > 1.0 {
                    bullets[idx].velocity = CGPoint(x: (dx / d) * bullets[idx].trackingSpeed, y: (dy / d) * bullets[idx].trackingSpeed)
                }
            }
            bullets[idx].pos.x += bullets[idx].velocity.x
            bullets[idx].pos.y += bullets[idx].velocity.y
            
            if bullets[idx].isEnemy && bullets[idx].willExplode && hypot(Double(playerPos.x - bullets[idx].pos.x), Double(playerPos.y - bullets[idx].pos.y)) < 25 {
                explosionRings.append(ExplosionRing(pos: bullets[idx].pos, radius: 10, maxRadius: 80, color: .orange))
                damagePlayer(amount: bullets[idx].damage * 2)
                spawnParticles(at: bullets[idx].pos, color: .orange)
                bullets.remove(at: idx)
                continue
            }
            if bullets[idx].pos.x < -100 || bullets[idx].pos.x > screenSize.width + 100 || bullets[idx].pos.y < -100 || bullets[idx].pos.y > screenSize.height + 100 {
                bullets.remove(at: idx)
            }
        }
        
        spawnTimer += 1
        if spawnTimer >= max(10, 45 - currentLevel * 2) {
            spawnTimer = 0
            let spawnPt = randomEdgePosition(screenSize: screenSize)
            let targetPt = CGPoint(x: CGFloat.random(in: 50...(screenSize.width - 50)), y: CGFloat.random(in: 50...(screenSize.height - 50)))
            let dx = targetPt.x - spawnPt.x
            let dy = targetPt.y - spawnPt.y
            let dist = max(1.0, CGFloat(hypot(Double(dx), Double(dy))))
            let moveVec = CGPoint(x: dx / dist, y: dy / dist)
            let scale = getLevelScaling()
            
            let isBossLevelType = currentLevel % 5 == 0 && !enemies.contains(where: { [.boss, .spinnerBoss, .diamondBoss, .pentagonBoss, .triangleBoss].contains($0.type) })
            
            if currentLevel >= 100 && currentLevel <= 200 {
                let r = Int.random(in: 0...4)
                let hp = Int(Double(currentLevel * (r == 3 ? 4 : 8)) * scale)
                let type: EnemyType = r == 0 ? .diamondBoss : (r == 1 ? .pentagonBoss : (r == 2 ? .triangleBoss : (r == 3 ? .whiteCircleOrbiter : .rectShooter)))
                let enemyColor: Color = r == 0 ? .cyan : (r == 1 ? .orange : (r == 2 ? .purple : .white))
                enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: r == 3 ? 1.4 : 1.2, radius: r == 3 ? 26 : 38, color: enemyColor, type: type, coinValue: Int(Double(currentLevel * 15) * scale), contactDamage: Int(Double(currentLevel * 4) * scale), orbitCount: Int.random(in: 1...3)))
            } else if isBossLevelType {
                let cycle = (currentLevel / 5) % 3
                let bossHp = Int(Double(currentLevel * (currentLevel == 15 ? 9 : 8)) * scale)
                let type: EnemyType = currentLevel == 15 ? .triangleBoss : (cycle == 1 ? .spinnerBoss : (cycle == 2 ? .diamondBoss : .boss))
                enemies.append(Enemy(pos: spawnPt, hp: bossHp, maxHp: bossHp, speed: 1.3, radius: 36, color: .purple, type: type, coinValue: Int(Double(currentLevel * 20) * scale), contactDamage: Int(Double(currentLevel * 6) * scale)))
            } else {
                let roll = Double.random(in: 0...1)
                if currentLevel >= 8 && roll < 0.15 {
                    enemies.append(Enemy(pos: spawnPt, hp: Int(2 * scale), maxHp: Int(2 * scale), speed: 1.0, radius: 16, color: .red, type: .sniper, coinValue: Int(4 * scale), contactDamage: Int(8 * scale)))
                } else if currentLevel >= 5 && roll < 0.35 {
                    enemies.append(Enemy(pos: spawnPt, hp: Int(4 * scale), maxHp: Int(4 * scale), speed: 1.6, radius: 20, color: .blue, type: .splitTarget, moveVector: moveVec, coinValue: Int(3 * scale), contactDamage: Int(10 * scale)))
                } else if currentLevel >= 3 && roll < 0.55 {
                    let hp = Int(Double(6 + currentLevel / 2) * scale)
                    enemies.append(Enemy(pos: spawnPt, hp: hp, maxHp: hp, speed: 0.9, radius: 24, color: .green, type: .tank, moveVector: moveVec, coinValue: Int(5 * scale), contactDamage: Int(15 * scale)))
                } else if roll < 0.75 {
                    enemies.append(Enemy(pos: spawnPt, hp: Int(scale), maxHp: Int(scale), speed: 4.2, radius: 12, color: .yellow, type: .speedster, moveVector: moveVec, coinValue: Int(2 * scale), contactDamage: Int(6 * scale)))
                } else {
                    enemies.append(Enemy(pos: spawnPt, hp: Int(scale), maxHp: Int(scale), speed: CGFloat.random(in: 2.0...3.0), radius: 14, color: .orange, type: .standard, moveVector: moveVec, coinValue: 1, contactDamage: 10))
                }
            }
        }
        
        let auraRad = (40 + CGFloat(saveData.frostSkillLevel * 15)) * (1.0 + Double(saveData.globalRangeLevel) * 0.2)
        
        for idx in (0..<enemies.count).reversed() {
            var curSpeed = enemies[idx].speed
            let dx = playerPos.x - enemies[idx].pos.x
            let dy = playerPos.y - enemies[idx].pos.y
            let dist = CGFloat(hypot(Double(dx), Double(dy)))
            if saveData.frostSkillLevel > 0 && dist < auraRad {
                curSpeed *= max(0.1, 1.0 - Double(saveData.frostSkillLevel) * 0.15)
            }
            
            if enemies[idx].type == .spinnerBoss {
                enemies[idx].rotationAngle += 0.12 * gameSpeedMultiplier
                enemies[idx].stateTimer += 1
                if enemies[idx].stateTimer > 180 {
                    enemies[idx].isSpinDashing.toggle()
                    enemies[idx].stateTimer = 0
                }
                if enemies[idx].isSpinDashing {
                    curSpeed *= 2.8
                    enemies[idx].rotationAngle += 0.25
                }
                if dist > 0 {
                    enemies[idx].pos.x += (dx / dist) * curSpeed
                    enemies[idx].pos.y += (dy / dist) * curSpeed
                }
            } else if [.diamondBoss, .pentagonBoss, .triangleBoss, .whiteCircleOrbiter, .rectShooter, .bombThrower].contains(enemies[idx].type) {
                enemies[idx].stateTimer += 1
                if enemies[idx].type == .diamondBoss && enemies[idx].stateTimer >= 150 {
                    enemies[idx].stateTimer = 0
                    for _ in 0..<3 {
                        drops.append(ItemDrop(pos: CGPoint(x: enemies[idx].pos.x + CGFloat.random(in: -35...35), y: enemies[idx].pos.y + CGFloat.random(in: -35...35)), isGem: true))
                    }
                    spawnParticles(at: enemies[idx].pos, color: .pink)
                } else if enemies[idx].type == .pentagonBoss && enemies[idx].stateTimer >= 160 {
                    enemies[idx].stateTimer = 0
                    for k in 0..<10 {
                        let a = atan2(Double(dy), Double(dx)) + Double(k - 5) * 0.12
                        bullets.append(Bullet(pos: enemies[idx].pos, velocity: CGPoint(x: CGFloat(cos(a) * 4), y: CGFloat(sin(a) * 4)), damage: Int(Double(currentLevel * 3) * getLevelScaling()), isEnemy: true, isTracking: true, trackingSpeed: 3.5, willExplode: true))
                    }
                } else if enemies[idx].type == .triangleBoss && enemies[idx].stateTimer >= 180 {
                    enemies[idx].stateTimer = 0
                    let a = atan2(Double(dy), Double(dx))
                    bullets.append(Bullet(pos: enemies[idx].pos, velocity: CGPoint(x: CGFloat(cos(a) * 6), y: CGFloat(sin(a) * 6)), damage: Int(Double(currentLevel * 4) * getLevelScaling()), isEnemy: true))
                } else if enemies[idx].type == .whiteCircleOrbiter {
                    enemies[idx].rotationAngle += 0.08 * gameSpeedMultiplier
                }
                
                if dist > 0 {
                    enemies[idx].pos.x += (dx / dist) * curSpeed
                    enemies[idx].pos.y += (dy / dist) * curSpeed
                }
            } else if [.speedster, .tank, .boss].contains(enemies[idx].type) {
                if dist > 0 {
                    enemies[idx].pos.x += (dx / dist) * curSpeed
                    enemies[idx].pos.y += (dy / dist) * curSpeed
                }
            } else if enemies[idx].type == .sniper {
                if dist < 180 {
                    enemies[idx].pos.x -= (dx / dist) * curSpeed * 0.8
                    enemies[idx].pos.y -= (dy / dist) * curSpeed * 0.8
                } else if dist > 260 {
                    enemies[idx].pos.x += (dx / dist) * curSpeed
                    enemies[idx].pos.y += (dy / dist) * curSpeed
                }
            } else {
                enemies[idx].pos.x += enemies[idx].moveVector.x * curSpeed
                enemies[idx].pos.y += enemies[idx].moveVector.y * curSpeed
            }
            
            if dist < (enemies[idx].radius + 14) {
                damagePlayer(amount: enemies[idx].contactDamage)
                spawnParticles(at: playerPos, color: .red)
                let isBossType = [.boss, .spinnerBoss, .diamondBoss, .pentagonBoss, .triangleBoss].contains(enemies[idx].type)
                if !isBossType {
                    enemies.remove(at: idx)
                    continue
                }
            }
        }
        
        for bIdx in (0..<bullets.count).reversed() {
            let b = bullets[bIdx]
            if b.isEnemy {
                if hypot(Double(playerPos.x - b.pos.x), Double(playerPos.y - b.pos.y)) < 18 {
                    damagePlayer(amount: b.damage)
                    spawnParticles(at: playerPos, color: .red)
                    bullets.remove(at: bIdx)
                }
                continue
            }
            for eIdx in 0..<enemies.count {
                if hypot(Double(enemies[eIdx].pos.x - b.pos.x), Double(enemies[eIdx].pos.y - b.pos.y)) < Double(enemies[eIdx].radius + 6) {
                    spawnParticles(at: b.pos, color: b.isCrit ? .yellow : enemies[eIdx].color)
                    enemies[eIdx].hp -= b.damage
                    if saveData.chainSkillLevel > 0 {
                        for otherIdx in 0..<enemies.count {
                            if otherIdx != eIdx && hypot(Double(enemies[otherIdx].pos.x - enemies[eIdx].pos.x), Double(enemies[otherIdx].pos.y - enemies[eIdx].pos.y)) < 120 {
                                enemies[otherIdx].hp -= saveData.chainSkillLevel * 2
                                lightningArcs.append(LightningArc(start: enemies[eIdx].pos, end: enemies[otherIdx].pos))
                                spawnParticles(at: enemies[otherIdx].pos, color: .cyan)
                            }
                        }
                    }
                    bullets.remove(at: bIdx)
                    break
                }
            }
        }
        
        for idx in (0..<lightningArcs.count).reversed() {
            lightningArcs[idx].life -= 0.016
            if lightningArcs[idx].life <= 0 { lightningArcs.remove(at: idx) }
        }
        for idx in (0..<explosionRings.count).reversed() {
            explosionRings[idx].radius += (explosionRings[idx].maxRadius - explosionRings[idx].radius) * 0.25
            explosionRings[idx].life -= 0.016
            if explosionRings[idx].life <= 0 { explosionRings.remove(at: idx) }
        }
        
        for eIdx in (0..<enemies.count).reversed() {
            if enemies[eIdx].hp <= 0 {
                let e = enemies[eIdx]
                let isBossType = [.boss, .spinnerBoss, .diamondBoss, .pentagonBoss, .triangleBoss].contains(e.type)
                if isBossType {
                    if currentLevel <= saveData.maxBossDefeatedLevel {
                        for _ in 0..<Int(Double(currentLevel * 10) * getLevelScaling()) {
                            drops.append(ItemDrop(pos: CGPoint(x: e.pos.x + CGFloat.random(in: -30...30), y: e.pos.y + CGFloat.random(in: -30...30))))
                        }
                    } else {
                        drops.append(ItemDrop(pos: e.pos, isGem: true))
                        saveData.maxBossDefeatedLevel = currentLevel
                    }
                    currentLevel += 1
                } else {
                    if e.type == .splitTarget {
                        for _ in 0..<2 {
                            enemies.append(Enemy(pos: e.pos, hp: 1, maxHp: 1, speed: 2.8, radius: 12, color: .cyan, coinValue: 1, contactDamage: 5))
                        }
                    }
                    for _ in 0..<e.coinValue {
                        drops.append(ItemDrop(pos: CGPoint(x: e.pos.x + CGFloat.random(in: -10...10), y: e.pos.y + CGFloat.random(in: -10...10))))
                    }
                    enemiesKilled += 1
                    if enemiesKilled % 8 == 0 { currentLevel += 1 }
                }
                enemies.remove(at: eIdx)
            }
        }
        
        let magnetRad = CGFloat(30 + saveData.magnetLevel * 25)
        for idx in (0..<drops.count).reversed() {
            let dx = playerPos.x - drops[idx].pos.x
            let dy = playerPos.y - drops[idx].pos.y
            let dist = CGFloat(hypot(Double(dx), Double(dy)))
            if saveData.magnetLevel > 0 && dist < magnetRad {
                drops[idx].pos.x += (dx / dist) * 6
                drops[idx].pos.y += (dy / dist) * 6
            }
            if dist < 20 {
                if drops[idx].isGem {
                    saveData.totalGems += 1
                    gemsCollected += 1
                } else {
                    saveData.totalCoins += 1
                    coinsCollected += 1
                }
                drops.remove(at: idx)
            }
        }
        
        for idx in (0..<particles.count).reversed() {
            particles[idx].pos.x += particles[idx].vx
            particles[idx].pos.y += particles[idx].vy
            particles[idx].life -= 0.05
            if particles[idx].life <= 0 { particles.remove(at: idx) }
        }
    }
    
    private func triggerSelfDestruct() {
        spawnParticles(at: playerPos, color: .orange)
        spawnParticles(at: playerPos, color: .red)
        playerHp = 0
        gameOver = true
    }
    
    private func damagePlayer(amount: Int) {
        var rem = amount
        if playerShield > 0 {
            if playerShield >= rem {
                playerShield -= rem
                rem = 0
            } else {
                rem -= playerShield
                playerShield = 0
            }
        }
        playerHp -= rem
        if playerHp <= 0 { gameOver = true }
    }
    
    private func randomEdgePosition(screenSize: CGSize) -> CGPoint {
        switch Int.random(in: 0...3) {
        case 0: return CGPoint(x: CGFloat.random(in: 0...screenSize.width), y: -20)
        case 1: return CGPoint(x: screenSize.width + 20, y: CGFloat.random(in: 0...screenSize.height))
        case 2: return CGPoint(x: CGFloat.random(in: 0...screenSize.width), y: screenSize.height + 20)
        default: return CGPoint(x: -20, y: CGFloat.random(in: 0...screenSize.height))
        }
    }
    
    private func spawnParticles(at pt: CGPoint, color: Color) {
        for _ in 0..<8 {
            let angle = Double.random(in: 0...6.2831)
            particles.append(Particle(pos: pt, vx: CGFloat(cos(angle) * 4), vy: CGFloat(sin(angle) * 4), life: 1.0, color: color))
        }
    }
    
    private func buy(_ currency: inout Int, cost: Int, apply: () -> Void) {
        guard currency >= cost else { return }
        currency -= cost
        apply()
    }
    
    private func startNewGame(screenSize: CGSize) {
        maxHp = 100 + saveData.healthLevel * 25
        playerHp = maxHp
        maxShield = Int(Double(saveData.shieldLevel * 20) * (1.0 + Double(saveData.globalRangeLevel) * 0.2))
        playerShield = maxShield
        playerPos = CGPoint(x: screenSize.width / 2, y: screenSize.height / 2)
        currentLevel = startLevelChoice
        enemiesKilled = 0
        coinsCollected = 0
        gemsCollected = 0
        enemies.removeAll()
        bullets.removeAll()
        drops.removeAll()
        particles.removeAll()
        lightningArcs.removeAll()
        explosionRings.removeAll()
        gameOver = false
        gameStarted = true
    }
    
    @ViewBuilder
    private func upgradeRow(title: String, level: Int, cost: Int, canAfford: Bool, onBuy: @escaping () -> Void) -> some View {
        baseRow(title: title, level: level, currency: "🪙", cost: cost, canAfford: canAfford, onBuy: onBuy)
    }
    
    @ViewBuilder
    private func gemUpgradeRow(title: String, level: Int, onBuy: @escaping () -> Void) -> some View {
        baseRow(title: title, level: level, currency: "💎", cost: 1, canAfford: saveData.totalGems >= 1, onBuy: onBuy)
    }
    
    @ViewBuilder
    private func baseRow(title: String, level: Int, currency: String, cost: Int, canAfford: Bool, onBuy: @escaping () -> Void) -> some View {
        HStack {
            VStack(alignment: .leading) {
                Text(title).font(.body).bold().monospaced().foregroundColor(.white)
                Text("Lvl \(level)").font(.caption).monospaced().foregroundColor(.gray)
            }
            Spacer()
            Button(action: onBuy) {
                Text("\(cost) \(currency)").font(.caption).bold().monospaced().foregroundColor(canAfford ? .black : .white).padding(.horizontal, 10).padding(.vertical, 5).background(canAfford ? Color.yellow : Color.gray.opacity(0.4)).cornerRadius(6)
            }
        }.padding(6).background(Color.white.opacity(0.05)).cornerRadius(8)
    }
}

